from pathlib import Path
from collections import Counter, defaultdict
import xml.etree.ElementTree as ET

# ----------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------

VSX_CACHE_FOLDER = "/data/projects/TESS-research/data_pipeline/VSXCache"

# Only XRAY-related cached XML
xml_files = (
    list(Path(VSX_CACHE_FOLDER).glob("vsx_response_X*.xml")) +
    list(Path(VSX_CACHE_FOLDER).glob("vsx_response_HMXB*.xml")) +
    list(Path(VSX_CACHE_FOLDER).glob("vsx_response_LMXB*.xml"))
)

xml_files = sorted(set(xml_files))

print(f"Found {len(xml_files)} XML files")

# ----------------------------------------------------------------------
# Parse XML
# ----------------------------------------------------------------------

type_counter = Counter()
type_files = defaultdict(set)

for xml_file in xml_files:

    try:
        tree = ET.parse(xml_file)
        root = tree.getroot()

        # FIELD definitions
        fields = root.findall(".//FIELD")

        if not fields:
            fields = root.findall(".//{*}FIELD")

        field_names = [
            field.attrib.get("name", "").strip()
            for field in fields
        ]

        if "VarType" not in field_names:
            print(f"WARNING: VarType column not found in {xml_file.name}")
            continue

        type_index = field_names.index("VarType")

        rows = root.findall(".//TR")

        if not rows:
            rows = root.findall(".//{*}TR")

        for row in rows:

            tds = row.findall("TD")

            if not tds:
                tds = row.findall("{*}TD")

            if len(tds) <= type_index:
                continue

            var_type = (tds[type_index].text or "").strip()

            type_counter[var_type] += 1
            type_files[var_type].add(xml_file.name)

    except Exception as ex:
        print(f"ERROR parsing {xml_file.name}: {ex}")

# ----------------------------------------------------------------------
# Report
# ----------------------------------------------------------------------

print()
print("=" * 70)
print("Distinct VSX VarType values")
print("=" * 70)

for t in sorted(type_counter):

    print(f"{t:35s} {type_counter[t]:6d}")

print()
print("=" * 70)
print("Composite VarType strings")
print("=" * 70)

found = False

for t in sorted(type_counter):

    if "/" in t or "+" in t or "|" in t:

        found = True

        print()
        print(f"{t}")
        print(f"Occurrences : {type_counter[t]}")

        for f in sorted(type_files[t]):
            print(f"    {f}")

if not found:
    print("No composite VSX Type strings found.")

print()
print("=" * 70)
print("Summary")
print("=" * 70)

print(f"Distinct VarType values : {len(type_counter)}")
print(f"Total rows           : {sum(type_counter.values())}")